var express = require('express');
var router = express.Router();
//bycrpt package for hasing passwords
const bcrypt = require("bcrypt");
//jwt tokens
//const jwt = require('jsonwebtoken');
//jwt secret
const JWT_SECRET = process.env.JWT_SECRET;
const jwt = require('jsonwebtoken');


/* GET users listing. */
router.get('/', function(req, res, next) {
  res.send('respond with a resource');
});

//register users
router.post('/register', function(req, res, next) {
  const email = req.body.email;
  const password = req.body.password;

  //verify both email an password included in body
  if (!email || !password) {
    res.status(400).json({ success: true, message: "Request body incomplete - requires email and password" });
  }
  else {
    //verifies if user already exists
    const queryUsers = req.db.from("users").select("*").where("email", "=", email);
    queryUsers.then(users => {
    if (users.length > 0){
      let error = new Error("User already exists");
      error.code = "409"
      throw error
    } 

    //salt and hash password then enter into db
    const saltRounds = 10;
    const hash = bcrypt.hashSync(password, saltRounds);
    return req.db.from("users").insert({ email, hash});
    })
    .then(() => {
      res.status(201).json({ success: true, message: "User created" });
    })
    .catch((error) => {
      res.status(error.code).json({ Error: true, Message: error.message });
    });
   }


})




//login and recieve token
router.post('/login', function (req, res, next) {
  const email = req.body.email;
  const password = req.body.password;

  //verify both email an password included in body
  if (!email || !password) {
    res.status(400).json({

      error: true,
      message: "Request body incomplete - requires email and password"
    });
    return;
  };

  //verifies if user already exists
  const queryUsers = req.db.from("users").select("*").where("email", "=", email);
  queryUsers
  .then(users => {
    if (users.length === 0){
      const error = new Error("User does not exist");
      error.code = "401"
      throw error
    }
    //compare user's password to ensure it is correct
    const user = users[0];
    return bcrypt.compare(password, user.hash);
  })
  .then(match => {
    if (!match) {
      const error = new Error("Incorrect password");
      error.code = "401"
      throw error
    } else {
      //Create JWT token
      const tokenExpiresIn = 600; //10 mins
      const exp = Math.floor(Date.now() / 1000) + tokenExpiresIn;
      const bearerToken = jwt.sign ({ exp }, process.env.JWT_SECRET)

      // Create refresh token
      const refreshExpiresIn = 846000; //20
      const refreshExp = Math.floor(Date.now()+ 1000) + refreshExpiresIn;
      const refreshToken = jwt.sign ({ refreshExp }, process.env.JWT_SECRET);

      process.env.loggedinEmail = req.body.email; //set users email in enviromentals storage
      process.env.currentToken = bearerToken; //set current token to bearertoken
      process.env.refreshToken = refreshToken; //set current token to bearertoken
      console.log("\n \nrefresh token at login", process.env.refreshToken)
      //refresh token
      setTimeout(() => {
        console.log("Bearer token expired. Removing token from enviroment storage.")
        process.env.currentToken = null
      }, tokenExpiresIn);

      setTimeout(() => {
        console.log("Refresh token expired. Removing token from enviroment storage.")
        process.env.refreshToken = null
      }, refreshExpiresIn);

      res.status(200).json({
        bearerToken: {
          token: bearerToken, 
          token_type: "Bearer",
          expires_in: tokenExpiresIn
        },
        refreshToken: {
          token: refreshToken, 
          token_type: "Refresh",
          expires_in: refreshExpiresIn
        }
      })
    }
  })
  .catch((error) => {
    res.status(error.code).json({ error: true, message: error.message });
  });
})

router.post('/refresh', function (req, res, next){
  //Grab refresh token from request body
  const refreshToken = req.body.refreshToken;
  //If user does not input refresh token
  if (!refreshToken) {
    res.status(400).json({ error: true, message: "Request body incomplete, refresh token required"});
  }  
  //if the stored refresh token has already been deleted/expired
  if (process.env.refreshToken == "null") {
    res.status(401).json({ error: true, message: "JWT token has expired" });
  } 
  //if the input refresh token does not match the stored refresh token
  else if (refreshToken != process.env.refreshToken){
    console.log("\ninput token", refreshToken)
    console.log("\nstorage token at refresh", process.env.refreshToken)
    res.status(401).json({ error: true, message: "Invalid JWT token" });
  } 
  //otherwise, create and replace tokens
  else {
    //Create JWT token
    const tokenExpiresIn = 600; //10 mins
    const exp = Math.floor(Date.now() / 1200000) + tokenExpiresIn;
    const bearerToken = jwt.sign ({ exp }, process.env.JWT_SECRET)

    // Create refresh token
    const refreshExpiresIn = 84600; //20 mins
    const refreshExp = Math.floor(Date.now()+ 1000) + refreshExpiresIn;
    const refreshToken = jwt.sign ({ refreshExp }, process.env.JWT_SECRET);

    process.env.currentToken = bearerToken; //set current token to bearertoken
    process.env.refreshToken = refreshToken; //set current token to bearertoken
    //refresh token
    setTimeout(() => {
     // console.log("Bearer token expired. Removing token from enviroment storage.")
      process.env.currentToken = null
    }, tokenExpiresIn);

    setTimeout(() => {
      //console.log("Refresh token expired. Removing token from enviroment storage.")
      process.env.refreshToken = null
    }, refreshExpiresIn);


    res.status(200).json({
      Data: {
        bearerToken: {
        token: bearerToken, 
        token_type: "Bearer",
        expires_in: tokenExpiresIn
      },
      refreshToken: {
        token: refreshToken, 
        token_type: "Bearer",
        expires_in: refreshExpiresIn
      }},
      Error: false,
      Messsage: "Successfully refreshed."
      
    })
  }
})

router.post('/logout', function (req, res, next) {
  //Grab refresh token from request body
  const refreshToken = req.body.refreshToken;

  //If user does not input refresh token
  if (!refreshToken) {
    res.status(400).json({ error: true, message: "Request body incomplete, refresh token required"});
  } 
  //if the stored refresh token has already been deleted/expired
  else if (process.env.refreshToken == null) {
    res.status(401).json({ error: true, message: "JWT token has expired" });
  } 
  //if the input refresh token does not match the stored refresh token
  else if (refreshToken != process.env.refreshToken){
    res.status(401).json({ error: true, message: "Invalid JWT token" });
  } 
  //otherwise, remove and invalidate all tokens
  else {
    process.env.loggedinEmail = null
    process.env.currentToken = null
    process.env.refreshToken = null
    res.status(200).json({ error: false, message: "Token successfully invalidated" });
  }
})


//router.post("/logout", function (req, res, next))
module.exports = router;
