var express = require('express');
var router = express.Router();
const authorization = require("../middleware/authorization");
const jwt = require('jsonwebtoken');
const swaggerUi = require('swagger-ui-express');
const swaggerOptions = {  
  swaggerOptions: {
  url: '../docs/swagger.json', // Replace with the path to your Swagger document JSON file or object
},}
const swaggerDocument = require('../docs/swagger.json');


/* GET home page.  */
router.use('/', swaggerUi.serve);
router.get('/', swaggerUi.setup(swaggerDocument));

/* router.get(
  swaggerUi.serve,
  function(req, res) {
    swaggerDocument.host = req.get("host"); // Replace hardcoded host information in swagger file
    swaggerDocument.schemes = [req.protocol]; // Replace hardcoded protocol information in Swagger file
    swaggerUi.setup(swaggerDocument)(req, res);
  }
); */

router.get("/movies/search", (req, res) => {
  let year = "null";
  let title = "null";
  let conditional = "!=";
  let conditional2 = "!=";
  let pageQuery = "null"

  if (req.query.title){
    title = req.query.title;
    conditional2 = "LIKE";
  }
  if (req.query.year){
    year = req.query.year;
    conditional = "=";
  }
  if (req.query.page){
    pageQuery = req.query.page;
  }

  if (year !== "null" && isNaN(Number(year)) || Number(year) > 9999 || Number(year) < 1000) {
    res.status(400).json({ error: true, message: "Invalid year format. Format must be yyyy."});
  } else if (pageQuery !== "null" && isNaN(pageQuery)){
    res.status(400).json({ message: "Invalid page format. page must be a number."})
    
  }
   else {
   console.log(pageQuery)
    req.db
    .from("basics")
    .select("primaryTitle AS title", "year", "tconst AS imdbID", "imdbRating", "rottenTomatoesRating", "metacriticRating", "rated AS classification")
    .where("year", conditional, year)
    .where("primaryTitle", conditional2, `%${title}%`)
    .then((rows) => {
      const itemsPerPage = 100;
      const lastPage = Math.ceil(rows.length/100);

      let page = 1;
      if (req.query.page){
        page = req.query.page
        page = parseInt(page);
      }
      let finalItemNumber = page*100;
      let firstItemNumber = finalItemNumber-100;

      let previousPage = page-1;
      if (previousPage == 0){
        previousPage = null;
      }
      
      let nextPage = Number(page)+1;
      if (page >= lastPage){
        nextPage = null;
        //finalItemNumber = finalItemNumber-100;
      }
      if (rows.length == "0" ) {
        nextPage = null;
        finalItemNumber = 0;
      }
      if (rows.length == "0" ) {
        finalItemNumber = 0;
      }  
      else if (finalItemNumber > rows.length){
        finalItemNumber = rows.length;
      }
      for (let i = 0; i<rows.length; i++){
        rows[i].imdbRating = parseFloat(rows[i].imdbRating);
        rows[i].rottenTomatoesRating = parseFloat(rows[i].rottenTomatoesRating);
        rows[i].metacriticRating = parseFloat(rows[i].metacriticRating);
      }
      if(rows.length == 0) {
        res.status(200).json({ data: [], pagination: { total: 0, lastPage: lastPage, prevPage: previousPage, nextPage: nextPage, perPage: itemsPerPage, currentPage: page, from: firstItemNumber, to: finalItemNumber}});
      } else{
        res.status(200).json({ data: rows.slice(((page*100)-100), (page*100)), pagination: { total: rows.length, lastPage: lastPage, prevPage: previousPage, nextPage: nextPage, perPage: itemsPerPage, currentPage: page, from: firstItemNumber, to: finalItemNumber}});
      }
      
    })
    .catch((error) => {
      res.status(500).json({ Error: true, Message: "Error in MySQL query", Error: error});
    })
  } 
})

router.get("/movies/data/:imdbID", (req, res) => {
  if(req.originalUrl.includes(`aQueryParam`)){
    res.status(400).json({ error: true, message: "Query parameters are not permitted."})
  }
  else {
    req.db
    .select("basics.primaryTitle AS title", 
            "basics.year", 
            "basics.runtimeMinutes AS runtime", 
            "basics.genres", "basics.country", 
            "basics.boxoffice", 
            "basics.poster", 
            "basics.plot")
    .where(function () {
        this.where("basics.id", "=", req.params.imdbID)
          .orWhere("basics.tconst", "=", req.params.imdbID);
      })
    .from("basics")
    .then((rows) => {
      if(rows.length == 0){
        res.status(404).json({ error: true, message: "Movie not found"});
      }
      else{
        res.status(200).json({  data: rows, error: false, message: "Success"});
      }
    })
    .catch((error) => {
      res.status(500).json({ Error: true, Message: "Error in MySQL query", Error: error});
    })
  }
})

router.get("/people/:id", authorization, (req, res) => {
  if(req.originalUrl.includes(`aQueryParam`)){
    res.status(400).json({ error: true, message: "Query parameters are not permitted."})
  }
  else {req.db
  .from("names")
  .select("*")
  .where("id", "=", req.params.id)
  .then((rows) => {
    if(rows.length = 0){
      res.status(404).json({ error: true, message: "Person not found"});
    }
    else{
      res.status(200).json({ Error: false, Message: "Success", Data: rows}); 
    }
  })
  .catch((error) => {
    res.status(500).json({ Error: true, Message: "Error in MySQL query", Error: error});
  })}
})

router.get("/user/profile", (req, res) => {
  res.status(404).json({ Error: true, Message: "No profile entered"});
});

router.get("/user/:email/profile", (req, res) => {
  //console.log("stored email in GET: ", process.env.loggedinEmail)
  req.db
  .from("users")
  .select("email", "firstName", "lastName", "dob", "address")
  .where("email", "=", req.params.email)
  .then((rows) => {
    //If returned list is equal to 0, user does not exist in database and is therefore not found
    if (rows.length === 0){
      let error = new Error("User not found");
      error.code = "404"
      throw error
    }
    //Otherwise Check for authorization and then return appropriate response
    else {
      //if the authorization is not in the req headers, return only the email, firstname and lastname of the user
      if (!("authorization" in req.headers)){
        res.status(200).json({ email: rows[0].email, firstName:  rows[0].firstName, lastName: rows[0].lastName });
      //otherwise if the authorization header exists but does not contain "bearer", return a 401 error
      } else if (process.env.loggedinEmail != req.params.email){
        res.status(200).json({ email: rows[0].email, firstName:  rows[0].firstName, lastName: rows[0].lastName });
      } else if (!(req.headers.authorization.match(/^Bearer /))){
        res.status(401).json({ Error: true, Message: "Authorization header is malformed"})
      } else { 
        //extract the token from the authorization header
        const token = req.headers.authorization.replace(/^Bearer /, "");
        try {
            //verify the token, if it is valid -> display all user information
            jwt.verify(token, process.env.JWT_SECRET);
            res.status(200).json({ email: rows[0].email, firstName:  rows[0].firstName, lastName: rows[0].lastName, dob: req.body.dob, address: req.body.address});
        } catch (e) {
            //alert the user if the token is expired or invalid
            if (e.name === "TokenExpiredError") {
                res.status(401).json({ error: true, message: "JWT token has expired" });
            } else {
                res.status(401).json({ error: true, message: "Invalid JWT token" });
            }
        }
      } 
    }
  })
  .catch((error) => {
    res.status(error.code).json({ error: true, message: error.message });
  });
});

router.put("/user/:email/profile", authorization, (req, res) => {
  const inputToken = req.headers.authorization.replace(/^Bearer /, "");
  console.log("stored token: ", process.env.currentToken)
  console.log("input token: ", inputToken)
  //test date 
  let testDateResult;
  function testDate(date){
    let pattern = /^([12]\d{3}-(0[1-9]|1[0-2])-(0[1-9]|[12]\d|3[01]))/;
    let matchPattern = date.match(pattern);
    if (matchPattern == null){
      return { 
        message: "Invalid input: dob must be a real date in format YYYY-MM-DD.",
        isTrue: false
      };
    }

    let dateStr = date.replace(/\D/g, '');

    let year = parseInt(dateStr.substr(0, 4));
    let month = parseInt(dateStr.substr(4, 2));
    let day = parseInt(dateStr.substr(6, 2));

    let daysInMonth  = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];

    if (year % 400 == 0 || (year % 100 != 0 && year % 4 ==0)){
      daysInMonth[1] = 29;
    }

    if (month < 1 || month > 12 || day < 1 || day > daysInMonth[month -1]){
      return {
        message: "Invalid input: dob must be a real date in format YYYY-MM-DD.",
        isTrue: false
      }
    }

    const isISOString = val => {
      const d = new Date(val);
      return !Number.isNaN(d.valueOf()) && d.toISOString() === val;
    }
    if(isISOString(date)){
      return {
        message: "Invalid input: dob must be a real date in format YYYY-MM-DD.",
        isTrue: false
      }
    }

    let currentDate = Date.now();
    let inputDate = new Date(date);
    let parsedInputDate = Date.parse(inputDate);
    if (currentDate <= parsedInputDate){
      return {
        message: "Invalid input: dob must be a date in the past.",
        isTrue: false
      }
    }
    
    return {
      isTrue: true
    }
  }
  if(req.body.dob){
    testDateResult = testDate(req.body.dob);
  }
  //if the logged in user's email does not match the email of the user they are searching for
    if (!req.body.firstName || !req.body.lastName || !req.body.dob || !req.body.address){
      res.status(400).json({ error: true, message: "Request body incomplete: firstName, lastName, dob and address are required." })
    } else if ((typeof req.body.firstName) != "string" || (typeof req.body.lastName) != "string" || (typeof req.body.dob) != "string"  ||  (typeof req.body.address) != "string" ){
      res.status(400).json({ error: true, message: "Request body invalid: firstName, lastName and address must be strings only." })
    } else if (testDateResult.isTrue == false) {
      res.status(400).json({ error: true, message: testDateResult.message })
      return;
    } else if (process.env.currentToken != inputToken){
      //console.log("stored token: ", process.env.currentToken)
      //console.log("input token: ", inputToken)
      //console.log("FORBIDDEN\n")
      res.status(403).json({ error: true, message: "Forbidden" })
    }
      else {
      const filter = {
        "email": req.params.email
      }
      const details = {
        "firstName" : req.body.firstName,
        "lastName" : req.body.lastName,
        "dob" : req.body.dob,
        "address" : req.body.address
      }
      req.db('users').where(filter).update(details)
      .then(_ => {
        req.db
        .from("users")
        .select("email", "firstName", "lastName", "dob", "address")
        .where("email", "=", req.params.email)
        .then((rows) => {
          //If returned list is equal to 0, user does not exist in database and is therefore not found
          if (rows.length == 0){
            const error = new Error("User not found");
            error.code = "404"
            throw error
          } else {
            res.status(200).json({ email: rows[0].email, firstName:  rows[0].firstName, lastName: rows[0].lastName, dob: req.body.dob, address: req.body.address});
          }
        })
      })
      .catch((error) => {
        res.status(error.code).json({ Error: true, Message: error.message });
      });
    }
  })

module.exports = router;
